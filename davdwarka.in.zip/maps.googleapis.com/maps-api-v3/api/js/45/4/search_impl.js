google.maps.__gjsload__('search_impl', function(_) {
    var xbb = function(a) {
            _.G(this, a, 4)
        },
        zbb = function(a) {
            ybb || (ybb = {
                oa: "sssM",
                Da: ["ss"]
            });
            var b = ybb;
            return _.gi.g(a.Jb(), b)
        },
        Abb = function(a, b) {
            a.W[0] = b
        },
        Bbb = function(a, b) {
            a.W[2] = b
        },
        X$ = function(a) {
            _.G(this, a, 3)
        },
        Cbb = function() {
            var a = _.ij,
                b = _.Ci;
            this.i = _.De;
            this.g = _.ck(_.br, a, _.Fr + "/maps/api/js/LayersService.GetFeature", b)
        },
        Fbb = function(a, b, c) {
            var d = _.EA(new Cbb);
            c.cr = (0, _.db)(d.load, d);
            c.clickable = 0 != a.get("clickable");
            _.LBa(c, _.uH(b));
            var e = [];
            e.push(_.I.addListener(c, "click", (0, _.db)(Dbb, null, a)));
            _.Db(["mouseover",
                "mouseout", "mousemove"
            ], function(f) {
                e.push(_.I.addListener(c, f, (0, _.db)(Ebb, null, a, f)))
            });
            e.push(_.I.addListener(a, "clickable_changed", function() {
                a.g.clickable = 0 != a.get("clickable")
            }));
            a.i = e
        },
        Dbb = function(a, b, c, d, e) {
            var f = null;
            if (e && (f = {
                    status: e.getStatus()
                }, 0 == e.getStatus())) {
                f.location = _.hk(e, 1) ? new _.pf(_.oe(e.getLocation(), 0), _.oe(e.getLocation(), 1)) : null;
                f.fields = {};
                for (var g = 0, h = _.xe(e, 2); g < h; ++g) {
                    var k = new _.AH(_.we(e, 2, g));
                    f.fields[k.getKey()] = k.Ab()
                }
            }
            _.I.trigger(a, "click", b, c, d, f)
        },
        Ebb = function(a,
            b, c, d, e, f, g) {
            var h = null;
            f && (h = {
                title: f[1].title,
                snippet: f[1].snippet
            });
            _.I.trigger(a, b, c, d, e, h, g)
        },
        Gbb = function() {},
        ybb;
    _.D(xbb, _.E);
    xbb.prototype.getParameter = function(a) {
        return new _.AH(_.we(this, 3, a))
    };
    _.D(X$, _.E);
    X$.prototype.getStatus = function() {
        return _.ne(this, 0, -1)
    };
    X$.prototype.getLocation = function() {
        return new _.ml(this.W[1])
    };
    Cbb.prototype.load = function(a, b) {
        function c(g) {
            g = new X$(g);
            b(g)
        }
        var d = new xbb;
        Abb(d, a.layerId.split("|")[0]);
        d.W[1] = a.g;
        Bbb(d, _.ye(_.Be(this.i)));
        for (var e in a.parameters) {
            var f = new _.AH(_.ve(d, 3));
            f.W[0] = e;
            f.W[1] = a.parameters[e]
        }
        a = zbb(d);
        this.g(a, c, c);
        return a
    };
    Cbb.prototype.cancel = function() {
        throw Error("Not implemented");
    };
    Gbb.prototype.Au = function(a) {
        if (_.Ph[15]) {
            var b = a.Le,
                c = a.Le = a.getMap();
            b && a.g && (a.j ? (b = b.__gm.g, b.set(b.get().Ig(a.g))) : a.g && _.gCa(a.g, b) && (_.Db(a.i || [], _.I.removeListener), a.i = null));
            if (c) {
                var d = a.get("layerId"),
                    e = a.get("spotlightDescription"),
                    f = a.get("paintExperimentIds"),
                    g = a.get("styler"),
                    h = a.get("mapsApiLayer");
                b = new _.Fl;
                d = d.split("|");
                b.layerId = d[0];
                for (var k = 1; k < d.length; ++k) {
                    var l = d[k].split(":");
                    b.parameters[l[0]] = l[1]
                }
                e && (b.spotlightDescription = new _.Xo(e));
                f && (b.paintExperimentIds = f.slice(0));
                g && (b.styler = new _.Il(g));
                h && (b.mapsApiLayer = new _.ok(h));
                a.g = b;
                a.j = a.get("renderOnBaseMap");
                a.j ? (a = c.__gm.g, a.set(a.get().Kf(b))) : Fbb(a, c, b);
                _.Lg(c, "Lg")
            }
        }
    };
    _.Ef("search_impl", new Gbb);
});