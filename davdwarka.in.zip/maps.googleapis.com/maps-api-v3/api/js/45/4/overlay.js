google.maps.__gjsload__('overlay', function(_) {
    var dt = function(a) {
            this.g = a
        },
        Gka = function() {},
        et = function(a) {
            a.Eo = a.Eo || new Gka;
            return a.Eo
        },
        Hka = function(a) {
            this.ob = new _.pi(function() {
                var b = a.Eo;
                if (a.getPanes()) {
                    if (a.getProjection()) {
                        if (!b.Cn && a.onAdd) a.onAdd();
                        b.Cn = !0;
                        a.draw()
                    }
                } else {
                    if (b.Cn)
                        if (a.onRemove) a.onRemove();
                        else a.remove();
                    b.Cn = !1
                }
            }, 0)
        },
        Ika = function(a, b) {
            function c() {
                return _.qi(e.ob)
            }
            var d = et(a),
                e = d.Cm;
            e || (e = d.Cm = new Hka(a));
            _.Db(d.Ma || [], _.I.removeListener);
            var f = d.Bb = d.Bb || new _.yr,
                g = b.__gm;
            f.bindTo("zoom", g);
            f.bindTo("offset", g);
            f.bindTo("center", g, "projectionCenterQ");
            f.bindTo("projection", b);
            f.bindTo("projectionTopLeft", g);
            f = d.Zr = d.Zr || new dt(f);
            f.bindTo("zoom", g);
            f.bindTo("offset", g);
            f.bindTo("projection", b);
            f.bindTo("projectionTopLeft", g);
            a.bindTo("projection", f, "outProjection");
            a.bindTo("panes", g);
            d.Ma = [_.I.addListener(a, "panes_changed", c), _.I.addListener(g, "zoom_changed", c), _.I.addListener(g, "offset_changed", c), _.I.addListener(b, "projection_changed", c), _.I.addListener(g, "projectioncenterq_changed", c)];
            c();
            b instanceof
            _.Vf && (_.Lg(b, "Ox"), _.xl("Ox", "-p", a))
        },
        Mka = function(a) {
            if (a) {
                var b = a.getMap();
                if (Jka(a) !== b && b && b instanceof _.Vf) {
                    var c = b.__gm;
                    c.overlayLayer ? a.__gmop = new Kka(b, a, c.overlayLayer) : c.i.then(function(d) {
                        d = d.Sc;
                        var e = new ft(b, d);
                        d.Nb(e);
                        c.overlayLayer = e;
                        Lka(a);
                        Mka(a)
                    })
                }
            }
        },
        Lka = function(a) {
            if (a) {
                var b = a.__gmop;
                b && (a.__gmop = null, _.yl("Ox", "-p", b.g), b.g.unbindAll(), b.g.set("panes", null), b.g.set("projection", null), b.j.Hg(b), b.i && (b.i = !1, b.g.onRemove ? b.g.onRemove() : b.g.remove()))
            }
        },
        Jka = function(a) {
            return (a =
                a.__gmop) ? a.map : null
        },
        Kka = function(a, b, c) {
            this.map = a;
            this.g = b;
            this.j = c;
            this.i = !1;
            _.Lg(this.map, "Ox");
            _.xl("Ox", "-p", this.g);
            c.Jf(this)
        },
        Nka = function(a, b) {
            a.g.get("projection") != b && (a.g.bindTo("panes", a.map.__gm), a.g.set("projection", b))
        },
        ft = function(a, b) {
            this.o = a;
            this.j = b;
            this.g = null;
            this.i = []
        };
    _.D(dt, _.L);
    dt.prototype.changed = function(a) {
        "outProjection" != a && (a = !!(this.get("offset") && this.get("projectionTopLeft") && this.get("projection") && _.We(this.get("zoom"))), a == !this.get("outProjection") && this.set("outProjection", a ? this.g : null))
    };
    var gt = {};
    _.D(Hka, _.L);
    gt.Jf = function(a) {
        if (a) {
            var b = a.getMap();
            (et(a).Gr || null) !== b && (b && Ika(a, b), et(a).Gr = b)
        }
    };
    gt.Hg = function(a) {
        var b = et(a),
            c = b.Bb;
        c && c.unbindAll();
        (c = b.Zr) && c.unbindAll();
        a.unbindAll();
        a.set("panes", null);
        a.set("projection", null);
        b.Ma && _.Db(b.Ma, _.I.removeListener);
        b.Ma = null;
        b.Cm && (b.Cm.ob.ke(), b.Cm = null);
        _.yl("Ox", "-p", a);
        delete et(a).Gr
    };
    var ht = {};
    Kka.prototype.draw = function() {
        this.i || (this.i = !0, this.g.onAdd && this.g.onAdd());
        this.g.draw && this.g.draw()
    };
    ft.prototype.dispose = function() {};
    ft.prototype.zd = function(a, b, c, d, e, f, g, h) {
        var k = this.g = this.g || new _.sn(this.o, this.j, function() {});
        k.zd(a, b, c, d, e, f, g, h);
        a = _.A(this.i);
        for (b = a.next(); !b.done; b = a.next()) b = b.value, Nka(b, k), b.draw()
    };
    ft.prototype.Jf = function(a) {
        this.i.push(a);
        this.g && Nka(a, this.g);
        this.j.refresh()
    };
    ft.prototype.Hg = function(a) {
        _.Rb(this.i, a)
    };
    ht.Jf = Mka;
    ht.Hg = Lka;
    _.Ef("overlay", {
        Up: function(a) {
            if (a) {
                (0, gt.Hg)(a);
                (0, ht.Hg)(a);
                var b = a.getMap();
                b && (b instanceof _.Vf ? (0, ht.Jf)(a) : (0, gt.Jf)(a))
            }
        },
        preventMapHitsFrom: function(a) {
            _.Yn(a, {
                onClick: function(b) {
                    return _.Dn(b.event)
                },
                Qd: function(b) {
                    return _.An(b)
                },
                li: function(b) {
                    return _.Bn(b)
                },
                Ce: function(b) {
                    return _.Bn(b)
                },
                de: function(b) {
                    return _.Cn(b)
                }
            }).ej(!0)
        },
        preventMapHitsAndGesturesFrom: function(a) {
            a.addEventListener("click", _.If);
            a.addEventListener("contextmenu", _.If);
            a.addEventListener("dblclick", _.If);
            a.addEventListener("mousedown",
                _.If);
            a.addEventListener("mousemove", _.If);
            a.addEventListener("MSPointerDown", _.If);
            a.addEventListener("pointerdown", _.If);
            a.addEventListener("touchstart", _.If);
            a.addEventListener("wheel", _.If)
        }
    });
});